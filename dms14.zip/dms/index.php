<?php
//This is visitor page
//
//require_once("auth.php");
//require_once("header.php");
header('Location: g/html/pages/');
//require_once("./g/html/pages/index.php");

?>


