<?php
//This is display page
//no auth
require_once("load.php");
require_once("db_connection.php");
require_once("functions.php");
// no level
//check_permission($level_add);
require_once("header.php");

require_once("view_js.php");
?>





    <div class="jumbotron app-header">
        <div class="container">
            <h2 class="text-center"><i class="app-logo fa fa-connectdevelop fa-5x color-white"></i><div class="color-white">中德科技学院 宿舍成绩查询</div></h2>

            <p class="text-center color-white app-description">

            </p>

            <!--             <p class="text-center"><a class="btn btn-primary btn-lg app-btn" href="#" role="button">Learn more »</a></p> -->

        </div>
    </div>


<!-- /END THE FEATURETTES -->
<!-- FOOTER -->
<footer class="app-footer">
  <div class="container">
    <!-- <hr /> -->
    <p class="text-muted">Powered by <a href="http://github.com/dasuan">dasuan</a> &copy; 2016, Copyleft. </p>
</div>
</footer>

<!-- /.container -->
</body>

</html>

