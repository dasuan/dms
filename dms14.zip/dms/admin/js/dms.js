// function validate_required(field,alerttxt)
// {
// 	with (field)
// 	{
// 		if (value==null||value==""||value=="none")
// 			{alert(alerttxt);return false}
// 		else {return true}
// 	}
// }

// function validate_form(thisform)
// {
// 	with (thisform)
// 	{


// 			if (validate_required(score0,"Email must be filled out!")==false)
// 				{score0.focus();return false}

// 	}
// }





