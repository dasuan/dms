<?php
//This is admin index page
require_once("auth.php");
require_once("header.php");


echo '
<h2 class="alert alert-success">欢迎使用中德宿舍成绩录入系统！</h1> 
<!-- <h1 class="alert alert-success">请在左侧列表选择要进行的操作~</h1> -->
<h2 class="alert alert-danger">请使用Chrome或Firefox浏览器，或切换到 <strong>极速模式！</strong>
<img src="images/webkit.png" /></h1>
<h2 class="alert alert-danger">为获得最佳浏览效果，请将浏览器窗口<strong>最大化！</strong></h1>
<h2 class="alert alert-danger">完成操作后请及时点右上角 <strong>退出！</strong></h1>
';
?>



