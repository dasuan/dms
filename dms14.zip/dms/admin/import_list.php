<?php
echo "<a href='import_dorm.php'>import_dorm | </a>";
echo "<a href='import_students.php'>import_students  </a>";
//echo "<a href='import_routine_date.php'>import_routine_date | </a>";
//echo "<a href='import_routine.php'>import_routine </a>";


?>