<?php  
//This script made a droplist 
//variable $i and $row['score']need to be predefined
?>


<select name='<?php echo "score"."$i";?>' class= 'form-control'>
<?php

switch ($row['score'])
{
case 100:
echo "<option value='100' selected='selected'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";	
  break;  
case 95:
echo "<option value='100'>100</option>
<option value='95' selected='selected'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";	
  break;
case 90:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90' selected='selected'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";	
  break;  
case 85:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85' selected='selected'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";	
  break;
case 80:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80' selected='selected'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";	
  break;  
case 75:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75' selected='selected'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";	
  break;
case 70:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70' selected='selected'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 65:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65' selected='selected'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 60:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60' selected='selected'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 55:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55' selected='selected'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 50:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50' selected='selected'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 45:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45' selected='selected'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 40:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'  selected='selected'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 35 :
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35' selected='selected'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 30:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30' selected='selected'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 25:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25' selected='selected'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 20:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20' selected='selected'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 15:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15' selected='selected'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 10:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10' selected='selected'>10</option>
<option value='5'>5</option>
<option value='0'>0</option>
</select>";
  break;  
case 5:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5' selected='selected'>5</option>
<option value='0'>0</option>
</select>";
  break;
case 0:
echo "<option value='100'>100</option>
<option value='95'>95</option>
<option value='90'>90</option>
<option value='85'>85</option>
<option value='80'>80</option>
<option value='75'>75</option>
<option value='70'>70</option>
<option value='65'>65</option>
<option value='60'>60</option>
<option value='55'>55</option>
<option value='50'>50</option>
<option value='45'>45</option>
<option value='40'>40</option>
<option value='35'>35</option>
<option value='30'>30</option>
<option value='25'>25</option>
<option value='20'>20</option>
<option value='15'>15</option>
<option value='10'>10</option>
<option value='5'>5</option>
<option value='0' selected='selected'>0</option>
</select>";
  break;








default: none;

	echo "an error";


}

?>

</select>
